MalOwn test fixture: benign archive member.
Contact: security@example.com
