#!/bin/sh
echo 'Running test fixture payload'
exit 0
